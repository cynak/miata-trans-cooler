

Sales_Staging -> Desired Mapping from Table in Dealer_PROD database
dealer_address -> Dealer_Location.address
dealer_city -> World_Cities.city_name = dealer_city and World_Cities.state_name = dealer_state -> Dealer_Location.city_id
dealer_phone -> Dealer_Location.phone
dealer_ -> Dealer.name = dealer_ -> Dealer_Location = Dealer.id
location_ -> Dealer_Location.name = location_ 
